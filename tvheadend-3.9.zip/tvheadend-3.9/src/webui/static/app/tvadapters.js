tvheadend.tvadapters = function() {
  return tvheadend.idnode_tree({ url: 'api/tvadapter/tree', title: 'TV adapters'});
}
