#define PARALLEL_MODE PARALLEL_64_MMX
#include "FFdecsa.c"
