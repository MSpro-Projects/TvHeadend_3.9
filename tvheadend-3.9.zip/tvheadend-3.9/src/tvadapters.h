#pragma once

#include "idnode.h"

idnode_t **tv_adapters_root(void);
